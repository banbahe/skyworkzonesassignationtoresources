# skyworkzonesassignationtoresources
Asignación de zonas de trabajo a recursos
